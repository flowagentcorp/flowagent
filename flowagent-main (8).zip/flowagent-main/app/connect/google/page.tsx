import ClientStatus from "./ClientStatus";

export default function ConnectGooglePage() {
  return <ClientStatus />;
}
